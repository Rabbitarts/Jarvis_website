const randomString = () => Math.random().toString(36).substring(7);

export default randomString;
